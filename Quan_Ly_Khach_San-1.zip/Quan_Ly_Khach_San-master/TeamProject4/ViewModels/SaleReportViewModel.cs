﻿using Team_Project_4.Models;

namespace Team_Project_4.ViewModels
{
    public class SaleReportViewModel
    {
        public Loaiphong loaiphongNavigation { get; set; }
        public float doanhThu {  get; set; }
        public float tyle {  get; set; }
    }
}
