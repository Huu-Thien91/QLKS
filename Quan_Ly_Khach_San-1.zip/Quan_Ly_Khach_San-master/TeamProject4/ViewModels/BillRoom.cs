﻿using Team_Project_4.Models;

namespace Team_Project_4.ViewModels
{
    public class BillRoom
    {
        public Hoadon Bill { get; set; }
        public string RoomType { get; set; }
    }

}
