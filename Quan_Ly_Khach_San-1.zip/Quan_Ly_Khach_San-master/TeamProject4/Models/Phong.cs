﻿using System;
using System.Collections.Generic;

namespace Team_Project_4.Models
{
    public partial class Phong
    {
        public Phong()
        {
            Khachhangs = new HashSet<Khachhang>();
            Phieuthues = new HashSet<Phieuthue>();
        }

        public int Map { get; set; }
        public string Tenphong { get; set; } = null!;
        public int Tinhtrang { get; set; }
        public int Soluongkhachtoida { get; set; }
        public string? Ghichu { get; set; }
        public int Maloaiphong { get; set; }
        public int Songayo { get; set; }

        public virtual Loaiphong MaloaiphongNavigation { get; set; } = null!;
        public virtual ICollection<Khachhang> Khachhangs { get; set; }
        public virtual ICollection<Phieuthue> Phieuthues { get; set; }
    }
}
