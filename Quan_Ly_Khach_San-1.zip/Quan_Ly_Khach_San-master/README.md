### YT video : https://youtu.be/-rLFMUjXxGY
## Bảng thành viên:
| STT | Tên thành viên   | Mã sinh viên | Nhiệm vụ                                                                                                                              |
| --- | ---------------- | ------------ | ------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Nguyễn Phúc Toàn | 81012202519  | - Chức năng đăng nhập, đăng xuất, cấp tài khoản <br> - Chức năng báo cáo tỷ lệ sử dụng phòng                                          |
| 2   | Lê Tấn Phát      | 81012202485  | - Chức năng quản lý & tra cứu, bootstrap phòng <br> - Thay đổi quy định loại phòng & số lượng khách tối đa. <br> - Tổng hợp code nhóm |
| 3   | Trần Ngân Bảo    | 81012202500  | - Chức năng quản lý & tra cứu, bootstrap nhân viên <br> - Quản lý PowerPoint <br> - Bootstrap phiếu thuê, hóa đơn                     |
| 4   | Hồng Đại Nghĩa   | 81012202505  | - Chức năng quản lý phiếu thuê, hóa đơn <br> - Thay đổi quy định phụ thu                                                              |
| 5   | Trần Tấn Lộc     | 81012202503  | - Chức năng quản lý & tra cứu, bootstrap khách hàng <br> - Quản lý file word <br> - Thay đổi quy định loại khách                      |

- Phần trên là source code của nhóm.
- Khi thực hiện đồ án thì bọn mình đang học kỳ 1 năm 2 của đại học Quốc Tế Sài Gòn và được thực hiện trong 2-3 tuần. Nên code có thể còn nhiều chỗ dư thừa. Mong các bạn thông cảm.
- Hướng code là chúng mình sẽ dùng Interface và Repository sau đó dăng ký serivce trong program. Và dùng Dependency Injection vô các controller. Từ đó có thể thuận tiện trong việc code logic.
- Là logic của bên phòng sẽ có thể dùng được bên phiếu thuê vì logic nằm trong folder Repositories.
- Tất cả tài liệu được đăng với mục đích cung cấp cho mọi tham khảo.
- NGHIÊM CẤM BÁN LẠI SẢN PHẨM
